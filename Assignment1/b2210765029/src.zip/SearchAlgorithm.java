public  class SearchAlgorithm {

}
